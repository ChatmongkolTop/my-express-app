// จำลองข้อมูล (ในงานจริงจะต่อ Database ตรงนี้)
const mockUsers = [
    { id: 1, name: 'Somchai', role: 'Admin' },
    { id: 2, name: 'Somsri', role: 'User' }
];

exports.getAllUsers = async () => {
    // จำลองการดึงข้อมูลแบบ Async
    return mockUsers;
};

exports.createUser = async (userData) => {
    const newUser = {
        id: mockUsers.length + 1,
        ...userData
    };
    mockUsers.push(newUser);
    return newUser;
};
