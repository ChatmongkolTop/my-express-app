const express = require('express');
const router = express.Router();
const userRoutes = require('./userRoutes');

// Prefix เส้นทางด้วย /users
router.use('/users', userRoutes);

module.exports = router;
