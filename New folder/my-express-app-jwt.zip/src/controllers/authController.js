const jwt = require('jsonwebtoken');

const SECRET_KEY = process.env.JWT_SECRET || 'my-secret-key-1234';

exports.login = async (req, res) => {
    const { username, password } = req.body;

    // จำลองการเช็ค User (ของจริงต้องเช็คจาก Database)
    if (username === 'admin' && password === '1234') {
        // สร้าง Token มีอายุ 1 ชั่วโมง
        const token = jwt.sign({ username: username, role: 'admin' }, SECRET_KEY, { expiresIn: '1h' });
        
        return res.json({ 
            message: 'Login successful',
            token: token 
        });
    }

    res.status(401).json({ message: 'Invalid credentials' });
};