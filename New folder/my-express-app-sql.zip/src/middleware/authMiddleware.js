const jwt = require('jsonwebtoken');

// ในการใช้งานจริง ควรเก็บ Secret Key ไว้ใน .env
const SECRET_KEY = process.env.JWT_SECRET || 'my-secret-key-1234';

module.exports = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

    if (!token) return res.status(401).json({ message: 'Access Denied: No Token Provided' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid Token' });
        req.user = user;
        next();
    });
};